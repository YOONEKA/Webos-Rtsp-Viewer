'use strict';

var net = require('net');
var http = require('http');
var crypto = require('crypto');
var urlParser = require('url');
var Service = require('webos-service');

var service = new Service('com.rtspdream.webos.service');

var activeSession = null;

function parseRtspUri(rawUrl) {
  var parsed = urlParser.parse(rawUrl);
  var port = parsed.port ? parseInt(parsed.port, 10) : 554;
  var username = '';
  var password = '';
  if (parsed.auth) {
    var parts = parsed.auth.split(':');
    username = decodeURIComponent(parts[0] || '');
    password = decodeURIComponent(parts.slice(1).join(':') || '');
  }
  var cleanUrl = 'rtsp://' + parsed.hostname + ':' + port + (parsed.path || '/');
  return {
    host: parsed.hostname,
    port: port,
    username: username,
    password: password,
    cleanUrl: cleanUrl
  };
}

function md5(str) {
  return crypto.createHash('md5').update(str).digest('hex');
}

function buildAuthHeader(challenge, method, uri, username, password) {
  if (!username) return null;
  if (/^Basic/i.test(challenge)) {
    return 'Basic ' + Buffer.from(username + ':' + password).toString('base64');
  }
  if (/^Digest/i.test(challenge)) {
    var realmMatch = challenge.match(/realm="([^"]+)"/i);
    var nonceMatch = challenge.match(/nonce="([^"]+)"/i);
    if (!realmMatch || !nonceMatch) return null;
    var realm = realmMatch[1];
    var nonce = nonceMatch[1];
    var ha1 = md5(username + ':' + realm + ':' + password);
    var ha2 = md5(method + ':' + uri);
    var response = md5(ha1 + ':' + nonce + ':' + ha2);
    return (
      'Digest username="' + username +
      '", realm="' + realm +
      '", nonce="' + nonce +
      '", uri="' + uri +
      '", response="' + response + '"'
    );
  }
  return null;
}

function createRtspClient(rtspUrl) {
  var info = parseRtspUri(rtspUrl);
  var socket = new net.Socket();
  var cseq = 1;
  var authChallenge = null;
  var sessionId = null;
  var buffer = Buffer.alloc(0);
  var pendingResolvers = [];
  var onInterleavedPacket = null;

  function processBuffer() {
    while (buffer.length > 0) {
      if (buffer[0] === 0x24) {
        // '$' RTP-over-TCP interleaved packet: [0x24, channel, lengthHi, lengthLo, ...payload]
        if (buffer.length < 4) break;
        var pktLen = buffer.readUInt16BE(2);
        if (buffer.length < 4 + pktLen) break;
        var channel = buffer[1];
        var payload = buffer.slice(4, 4 + pktLen);
        buffer = buffer.slice(4 + pktLen);
        if (onInterleavedPacket) onInterleavedPacket(channel, payload);
      } else {
        var headerEnd = buffer.indexOf('\r\n\r\n');
        if (headerEnd === -1) break;
        var headerText = buffer.slice(0, headerEnd).toString('utf8');
        var clMatch = headerText.match(/Content-Length:\s*(\d+)/i);
        var bodyLen = clMatch ? parseInt(clMatch[1], 10) : 0;
        if (buffer.length < headerEnd + 4 + bodyLen) break;
        var body = buffer.slice(headerEnd + 4, headerEnd + 4 + bodyLen).toString('utf8');
        buffer = buffer.slice(headerEnd + 4 + bodyLen);

        var statusMatch = headerText.match(/^RTSP\/\d\.\d\s+(\d+)\s+(.*)$/m);
        var statusCode = statusMatch ? parseInt(statusMatch[1], 10) : 0;
        var wwwAuth = headerText.match(/WWW-Authenticate:\s*(.+)$/im);
        var sessMatch = headerText.match(/Session:\s*([^;\r\n]+)/im);
        if (sessMatch) sessionId = sessMatch[1].trim();

        var resolver = pendingResolvers.shift();
        if (resolver) {
          resolver({
            statusCode: statusCode,
            headers: headerText,
            body: body,
            wwwAuthenticate: wwwAuth ? wwwAuth[1].trim() : null
          });
        }
      }
    }
  }

  socket.on('data', function (chunk) {
    buffer = Buffer.concat([buffer, chunk]);
    processBuffer();
  });

  function sendRequest(method, targetUri, extraHeaders) {
    return new Promise(function (resolve, reject) {
      var seq = cseq++;
      var lines = [method + ' ' + targetUri + ' RTSP/1.0', 'CSeq: ' + seq, 'User-Agent: RtspDreamWebOS/1.0'];
      if (sessionId) lines.push('Session: ' + sessionId);
      if (authChallenge) {
        var auth = buildAuthHeader(authChallenge, method, targetUri, info.username, info.password);
        if (auth) lines.push('Authorization: ' + auth);
      }
      if (extraHeaders) {
        extraHeaders.forEach(function (h) { lines.push(h); });
      }
      lines.push('', '');

      var timer = setTimeout(function () {
        reject(new Error('RTSP ' + method + ' timed out'));
      }, 8000);

      pendingResolvers.push(function (resp) {
        clearTimeout(timer);
        if (resp.statusCode === 401 && resp.wwwAuthenticate && !authChallenge) {
          authChallenge = resp.wwwAuthenticate;
          sendRequest(method, targetUri, extraHeaders).then(resolve).catch(reject);
        } else {
          resolve(resp);
        }
      });

      socket.write(lines.join('\r\n'));
    });
  }

  return {
    info: info,
    socket: socket,
    connect: function () {
      return new Promise(function (resolve, reject) {
        var timer = setTimeout(function () {
          socket.destroy();
          reject(new Error('TCP connection to ' + info.host + ':' + info.port + ' timed out'));
        }, 8000);
        socket.once('error', function (err) {
          clearTimeout(timer);
          reject(err);
        });
        socket.connect(info.port, info.host, function () {
          clearTimeout(timer);
          resolve();
        });
      });
    },
    sendRequest: sendRequest,
    setPacketHandler: function (fn) { onInterleavedPacket = fn; },
    close: function () {
      try { socket.destroy(); } catch (e) {}
    }
  };
}

// --- Minimal ISO-BMFF fMP4 Builder for H.264-over-HTTP MSE Playback ---
function box(type, payload) {
  var b = Buffer.alloc(8 + payload.length);
  b.writeUInt32BE(b.length, 0);
  b.write(type, 4, 4, 'ascii');
  payload.copy(b, 8);
  return b;
}

function fullBox(type, version, flags, payload) {
  var hdr = Buffer.alloc(4);
  hdr[0] = version;
  hdr[1] = (flags >> 16) & 0xff;
  hdr[2] = (flags >> 8) & 0xff;
  hdr[3] = flags & 0xff;
  return box(type, Buffer.concat([hdr, payload]));
}

function buildFtypMoov(sps, pps) {
  var ftyp = box('ftyp', Buffer.from('isom\x00\x00\x02\x00isomiso2avc1mp41', 'binary'));

  var mvhdPayload = Buffer.alloc(96);
  mvhdPayload.writeUInt32BE(90000, 12); // timescale
  mvhdPayload.writeUInt32BE(0xffffffff, 16);
  mvhdPayload.writeUInt32BE(0x00010000, 20); // rate 1.0
  mvhdPayload.writeUInt16BE(0x0100, 24);
  mvhdPayload.writeUInt32BE(0x00010000, 36);
  mvhdPayload.writeUInt32BE(0x00010000, 52);
  mvhdPayload.writeUInt32BE(0x40000000, 68);
  mvhdPayload.writeUInt32BE(2, 92); // next track id
  var mvhd = fullBox('mvhd', 0, 0, mvhdPayload);

  var tkhdPayload = Buffer.alloc(80);
  tkhdPayload.writeUInt32BE(1, 8); // track id
  tkhdPayload.writeUInt32BE(0x00010000, 36);
  tkhdPayload.writeUInt32BE(0x00010000, 52);
  tkhdPayload.writeUInt32BE(0x40000000, 68);
  tkhdPayload.writeUInt32BE(1920 << 16, 72);
  tkhdPayload.writeUInt32BE(1080 << 16, 76);
  var tkhd = fullBox('tkhd', 0, 7, tkhdPayload);

  var mdhdPayload = Buffer.alloc(20);
  mdhdPayload.writeUInt32BE(90000, 8);
  mdhdPayload.writeUInt16BE(0x55c4, 16);
  var mdhd = fullBox('mdhd', 0, 0, mdhdPayload);

  var hdlrPayload = Buffer.concat([Buffer.alloc(4), Buffer.from('vide'), Buffer.alloc(12), Buffer.from('VideoHandler\0')]);
  var hdlr = fullBox('hdlr', 0, 0, hdlrPayload);

  var vmhd = fullBox('vmhd', 0, 1, Buffer.alloc(8));
  var urlBox = fullBox('url ', 0, 1, Buffer.alloc(0));
  var dref = fullBox('dref', 0, 0, Buffer.concat([Buffer.from([0, 0, 0, 1]), urlBox]));
  var dinf = box('dinf', dref);

  var avcCData = Buffer.concat([
    Buffer.from([1, sps[1] || 0x42, sps[2] || 0xc0, sps[3] || 0x1f, 0xff, 0xe1]),
    Buffer.from([(sps.length >> 8) & 0xff, sps.length & 0xff]),
    sps,
    Buffer.from([1, (pps.length >> 8) & 0xff, pps.length & 0xff]),
    pps
  ]);
  var avcC = box('avcC', avcCData);

  var avc1Header = Buffer.alloc(78);
  avc1Header.writeUInt16BE(1, 6);
  avc1Header.writeUInt16BE(1920, 24);
  avc1Header.writeUInt16BE(1080, 26);
  avc1Header.writeUInt32BE(0x00480000, 28);
  avc1Header.writeUInt32BE(0x00480000, 32);
  avc1Header.writeUInt16BE(1, 40);
  avc1Header.writeUInt16BE(24, 74);
  avc1Header.writeInt16BE(-1, 76);
  var avc1 = box('avc1', Buffer.concat([avc1Header, avcC]));

  var stsd = fullBox('stsd', 0, 0, Buffer.concat([Buffer.from([0, 0, 0, 1]), avc1]));
  var stts = fullBox('stts', 0, 0, Buffer.alloc(4));
  var stsc = fullBox('stsc', 0, 0, Buffer.alloc(4));
  var stsz = fullBox('stsz', 0, 0, Buffer.alloc(8));
  var stco = fullBox('stco', 0, 0, Buffer.alloc(4));
  var stbl = box('stbl', Buffer.concat([stsd, stts, stsc, stsz, stco]));

  var minf = box('minf', Buffer.concat([vmhd, dinf, stbl]));
  var mdia = box('mdia', Buffer.concat([mdhd, hdlr, minf]));
  var trak = box('trak', Buffer.concat([tkhd, mdia]));

  var trexPayload = Buffer.alloc(20);
  trexPayload.writeUInt32BE(1, 0);
  trexPayload.writeUInt32BE(1, 4);
  var trex = fullBox('trex', 0, 0, trexPayload);
  var mvex = box('mvex', trex);

  var moov = box('moov', Buffer.concat([mvhd, trak, mvex]));
  return Buffer.concat([ftyp, moov]);
}

function buildMoofMdat(seqNum, dts, nalUnits) {
  var avccSamples = [];
  for (var i = 0; i < nalUnits.length; i++) {
    var nal = nalUnits[i];
    var lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(nal.length, 0);
    avccSamples.push(lenBuf, nal);
  }
  var samplePayload = Buffer.concat(avccSamples);

  var mfhdPayload = Buffer.alloc(4);
  mfhdPayload.writeUInt32BE(seqNum, 0);
  var mfhd = fullBox('mfhd', 0, 0, mfhdPayload);

  var tfhdPayload = Buffer.alloc(4);
  tfhdPayload.writeUInt32BE(1, 0);
  var tfhd = fullBox('tfhd', 0, 0x020000, tfhdPayload);

  var tfdtPayload = Buffer.alloc(4);
  tfdtPayload.writeUInt32BE(dts >>> 0, 0);
  var tfdt = fullBox('tfdt', 0, 0, tfdtPayload);

  var isKey = nalUnits.some(function (n) { return (n[0] & 0x1f) === 5; });
  var trunPayload = Buffer.alloc(20);
  trunPayload.writeUInt32BE(1, 0); // sample_count
  trunPayload.writeInt32BE(0, 4); // data_offset patched below
  trunPayload.writeUInt32BE(3000, 8); // sample_duration (~33ms @ 90kHz)
  trunPayload.writeUInt32BE(samplePayload.length, 12); // sample_size
  trunPayload.writeUInt32BE(isKey ? 0x02000000 : 0x01010000, 16); // sample_flags
  var trun = fullBox('trun', 0, 0x000701, trunPayload);

  var traf = box('traf', Buffer.concat([tfhd, tfdt, trun]));
  var moof = box('moof', Buffer.concat([mfhd, traf]));
  var dataOffset = moof.length + 8;
  // Patch data_offset inside trun (20-byte payload at end of moof -> offset 4 of trun payload)
  moof.writeInt32BE(dataOffset, moof.length - 16);

  var mdat = box('mdat', samplePayload);
  return Buffer.concat([moof, mdat]);
}

// --- Service Methods ---
service.register('testStream', function (message) {
  var rtspUrl = (message.payload && message.payload.rtspUrl) || '';
  if (!rtspUrl) {
    message.respond({ returnValue: false, errorText: 'Missing rtspUrl' });
    return;
  }

  var client = createRtspClient(rtspUrl);
  client.connect()
    .then(function () { return client.sendRequest('OPTIONS', client.info.cleanUrl); })
    .then(function () { return client.sendRequest('DESCRIBE', client.info.cleanUrl, ['Accept: application/sdp']); })
    .then(function (resp) {
      client.close();
      if (resp.statusCode >= 400) {
        message.respond({ returnValue: false, errorText: 'RTSP DESCRIBE returned HTTP/RTSP ' + resp.statusCode });
        return;
      }
      var codecMatch = resp.body.match(/a=rtpmap:\d+\s+([A-Za-z0-9_-]+)/i);
      message.respond({
        returnValue: true,
        codec: codecMatch ? codecMatch[1] : 'H.264',
        sdpLength: resp.body.length
      });
    })
    .catch(function (err) {
      client.close();
      message.respond({ returnValue: false, errorText: err.message || 'RTSP handshake failed' });
    });
});

function stopActiveSession() {
  if (!activeSession) return;
  var s = activeSession;
  activeSession = null;
  try {
    s.client.sendRequest('TEARDOWN', s.client.info.cleanUrl).catch(function () {});
  } catch (e) {}
  s.client.close();
  s.clients.forEach(function (res) { try { res.end(); } catch (e) {} });
  try { s.server.close(); } catch (e) {}
}

service.register('stopStream', function (message) {
  stopActiveSession();
  message.respond({ returnValue: true });
});

service.register('startStream', function (message) {
  stopActiveSession();
  var rtspUrl = (message.payload && message.payload.rtspUrl) || '';
  if (!rtspUrl) {
    message.respond({ returnValue: false, errorText: 'Missing rtspUrl' });
    return;
  }

  var client = createRtspClient(rtspUrl);
  var sps = null;
  var pps = null;
  var initSegment = null;
  var httpClients = [];
  var seqNum = 1;
  var fuaBuf = [];
  var currentAu = [];
  var lastTimestamp = null;

  var server = http.createServer(function (req, res) {
    res.writeHead(200, {
      'Content-Type': 'video/mp4',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*'
    });
    if (initSegment) res.write(initSegment);
    httpClients.push(res);
    req.on('close', function () {
      httpClients = httpClients.filter(function (c) { return c !== res; });
    });
  });

  function flushAu(ts) {
    if (!currentAu.length) return;
    if (!initSegment && sps && pps) {
      initSegment = buildFtypMoov(sps, pps);
      httpClients.forEach(function (c) { try { c.write(initSegment); } catch (e) {} });
    }
    if (initSegment) {
      var chunk = buildMoofMdat(seqNum++, ts || 0, currentAu);
      httpClients.forEach(function (c) { try { c.write(chunk); } catch (e) {} });
    }
    currentAu = [];
  }

  function handleNal(nal, ts) {
    if (!nal || !nal.length) return;
    var type = nal[0] & 0x1f;
    if (type === 7) { sps = nal; return; }
    if (type === 8) { pps = nal; return; }
    if (lastTimestamp !== null && ts !== lastTimestamp) {
      flushAu(lastTimestamp);
    }
    lastTimestamp = ts;
    currentAu.push(nal);
  }

  client.setPacketHandler(function (channel, rtp) {
    if (channel !== 0 || rtp.length < 12) return;
    var ts = rtp.readUInt32BE(4);
    var cc = rtp[0] & 0x0f;
    var offset = 12 + cc * 4;
    if (offset >= rtp.length) return;
    var payload = rtp.slice(offset);
    var nalType = payload[0] & 0x1f;

    if (nalType >= 1 && nalType <= 23) {
      handleNal(payload, ts);
    } else if (nalType === 28 && payload.length > 2) {
      // FU-A fragmentation
      var fuHeader = payload[1];
      var start = (fuHeader & 0x80) !== 0;
      var end = (fuHeader & 0x40) !== 0;
      var reconstructedHeader = (payload[0] & 0xe0) | (fuHeader & 0x1f);
      if (start) {
        fuaBuf = [Buffer.from([reconstructedHeader]), payload.slice(2)];
      } else if (fuaBuf.length > 0) {
        fuaBuf.push(payload.slice(2));
      }
      if (end && fuaBuf.length > 0) {
        handleNal(Buffer.concat(fuaBuf), ts);
        fuaBuf = [];
      }
    }
  });

  server.listen(0, '127.0.0.1', function () {
    var addr = server.address();
    var localUrl = 'http://127.0.0.1:' + addr.port + '/stream.mp4';
    activeSession = { client: client, server: server, clients: httpClients };

    client.connect()
      .then(function () { return client.sendRequest('OPTIONS', client.info.cleanUrl); })
      .then(function () { return client.sendRequest('DESCRIBE', client.info.cleanUrl, ['Accept: application/sdp']); })
      .then(function (desc) {
        var sprop = desc.body.match(/sprop-parameter-sets=([^;\r\n]+)/i);
        if (sprop) {
          var sets = sprop[1].split(',');
          if (sets[0]) sps = Buffer.from(sets[0], 'base64');
          if (sets[1]) pps = Buffer.from(sets[1], 'base64');
        }
        var ctrlMatch = desc.body.match(/a=control:([^\r\n]+)/ig);
        var trackUri = client.info.cleanUrl;
        if (ctrlMatch && ctrlMatch.length > 1) {
          var track = ctrlMatch[1].replace(/^a=control:/i, '').trim();
          trackUri = /^rtsp/i.test(track) ? track : client.info.cleanUrl.replace(/\/$/, '') + '/' + track;
        }
        return client.sendRequest('SETUP', trackUri, ['Transport: RTP/AVP/TCP;unicast;interleaved=0-1']);
      })
      .then(function () { return client.sendRequest('PLAY', client.info.cleanUrl, ['Range: npt=0.000-']); })
      .then(function () {
        message.respond({ returnValue: true, httpUrl: localUrl });
      })
      .catch(function (err) {
        stopActiveSession();
        message.respond({ returnValue: false, errorText: err.message || 'Failed to start RTSP stream' });
      });
  });
});
