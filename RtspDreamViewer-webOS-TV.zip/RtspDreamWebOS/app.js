(function () {
  'use strict';

  var STORAGE_KEY = 'rtsp_webos_settings_v1';
  var SERVICE_URI = 'luna://com.rtspdream.webos.service';
  var BACKOFF_DELAYS_SEC = [2, 4, 8, 15];

  var urlParams = new URLSearchParams(window.location.search || '');
  var launchedAsScreensaver = urlParams.get('mode') === 'screensaver';

  var state = {
    settings: loadSettings(),
    currentScreen: 'viewer', // 'viewer' | 'settings'
    screensaverMode: launchedAsScreensaver,
    showGearOverlay: false,
    gearTimer: null,
    reconnectTimer: null,
    countdownTimer: null,
    retryAttempt: 0,
    isTesting: false,
    activePlaybackUrl: null
  };

  // DOM Elements
  var viewerScreen = document.getElementById('viewer-screen');
  var settingsScreen = document.getElementById('settings-screen');
  var videoEl = document.getElementById('rtsp-video');
  var statusOverlay = document.getElementById('status-overlay');
  var statusSpinner = document.getElementById('status-spinner');
  var statusTitle = document.getElementById('status-title');
  var statusDetail = document.getElementById('status-detail');
  var floatingGearBtn = document.getElementById('floating-settings-btn');

  var btnBack = document.getElementById('btn-back');
  var settingsHeading = document.getElementById('settings-heading');
  var inputStreamUrl = document.getElementById('input-stream-url');
  var inputRelayUrl = document.getElementById('input-relay-url');
  var urlError = document.getElementById('url-error');
  var toggleTcp = document.getElementById('toggle-tcp');
  var toggleMute = document.getElementById('toggle-mute');
  var testResultBanner = document.getElementById('test-result-banner');
  var testBannerTitle = document.getElementById('test-banner-title');
  var testBannerDetail = document.getElementById('test-banner-detail');
  var btnSaveTest = document.getElementById('btn-save-test');
  var btnOpenViewer = document.getElementById('btn-open-viewer');
  var btnStartScreensaver = document.getElementById('btn-start-screensaver');

  var draftTcp = state.settings.forceRtpTcp;
  var draftMute = state.settings.muteAudio;

  // --- Persistence (localStorage across Viewer & Screensaver) ---
  function loadSettings() {
    try {
      var raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        return {
          streamUrl: typeof parsed.streamUrl === 'string' ? parsed.streamUrl.trim() : '',
          relayBaseUrl: typeof parsed.relayBaseUrl === 'string' ? parsed.relayBaseUrl.trim() : '',
          forceRtpTcp: typeof parsed.forceRtpTcp === 'boolean' ? parsed.forceRtpTcp : true,
          muteAudio: typeof parsed.muteAudio === 'boolean' ? parsed.muteAudio : true
        };
      }
    } catch (e) {
      // ignore storage failure
    }
    return {
      streamUrl: '',
      relayBaseUrl: '',
      forceRtpTcp: true,
      muteAudio: true
    };
  }

  function saveSettings(next) {
    state.settings = next;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (e) {
      // ignore storage failure
    }
  }

  function validateUrl(url) {
    var trimmed = (url || '').trim();
    if (!trimmed) {
      return 'Enter an RTSP or HLS stream URL (e.g. rtsp://192.168.1.50:554/stream).';
    }
    if (!/^(rtsps?|https?):\/\//i.test(trimmed)) {
      return 'URL must start with rtsp://, rtsps://, http://, or https://.';
    }
    return null;
  }

  // --- Luna / WebOSServiceBridge Helpers ---
  function callLunaService(serviceUri, method, params, onSuccess, onError) {
    if (typeof window.WebOSServiceBridge !== 'function') {
      if (onError) onError('WebOSServiceBridge unavailable (browser preview mode)');
      return null;
    }
    try {
      var bridge = new window.WebOSServiceBridge();
      bridge.onservicecallback = function (msg) {
        try {
          var res = JSON.parse(msg);
          if (res && res.returnValue === false) {
            if (onError) onError(res.errorText || 'Service call failed');
          } else if (onSuccess) {
            onSuccess(res);
          }
        } catch (err) {
          if (onError) onError(err.message);
        }
      };
      bridge.call(serviceUri + '/' + method, JSON.stringify(params || {}));
      return bridge;
    } catch (err) {
      if (onError) onError(err.message);
      return null;
    }
  }

  // Prevent LG TV's stock screensaver from interrupting active viewer playback
  var tvPowerBridge = null;
  function registerScreensaverSuppressor() {
    if (typeof window.WebOSServiceBridge !== 'function' || state.screensaverMode) return;
    try {
      tvPowerBridge = new window.WebOSServiceBridge();
      tvPowerBridge.onservicecallback = function (msg) {
        try {
          var data = JSON.parse(msg);
          if (data && data.state === 'Active' && state.currentScreen === 'viewer') {
            var reply = new window.WebOSServiceBridge();
            reply.call(
              'luna://com.webos.service.tvpower/power/responseScreenSaverRequest',
              JSON.stringify({
                clientName: 'com.rtspdream.webos',
                ack: false,
                timestamp: data.timestamp
              })
            );
          }
        } catch (e) {
          // ignore
        }
      };
      tvPowerBridge.call(
        'luna://com.webos.service.tvpower/power/registerScreenSaverRequest',
        JSON.stringify({
          subscribe: true,
          clientName: 'com.rtspdream.webos'
        })
      );
    } catch (e) {
      // ignore if service permission unavailable
    }
  }

  // --- Playback & Auto-Reconnect ---
  function setStatus(visible, title, detail, showSpinner) {
    if (!visible || state.screensaverMode) {
      statusOverlay.classList.add('hidden');
      return;
    }
    statusOverlay.classList.remove('hidden');
    statusTitle.textContent = title || '';
    statusDetail.textContent = detail || '';
    statusSpinner.style.display = showSpinner ? 'block' : 'none';
  }

  function clearReconnectTimers() {
    if (state.reconnectTimer) {
      window.clearTimeout(state.reconnectTimer);
      state.reconnectTimer = null;
    }
    if (state.countdownTimer) {
      window.clearInterval(state.countdownTimer);
      state.countdownTimer = null;
    }
  }

  function stopPlayback() {
    clearReconnectTimers();
    videoEl.pause();
    videoEl.removeAttribute('src');
    videoEl.load();
    state.activePlaybackUrl = null;
    callLunaService(SERVICE_URI, 'stopStream', {});
  }

  function resolvePlayableUrl(settings, onResolved, onError) {
    var url = settings.streamUrl.trim();
    var relay = (settings.relayBaseUrl || '').trim().replace(/\/+$/, '');

    // Direct HTTP/HTTPS streams (HLS .m3u8, MP4, go2rtc HTTP) play natively in <video>
    if (/^https?:\/\//i.test(url)) {
      onResolved(url);
      return;
    }

    // If user configured a go2rtc / MediaMTX relay gateway, route RTSP through it
    if (relay) {
      onResolved(relay + '/api/stream.mp4?src=' + encodeURIComponent(url));
      return;
    }

    // Otherwise use the bundled webOS Node.js RTSP-over-TCP -> fMP4 service
    callLunaService(
      SERVICE_URI,
      'startStream',
      {
        rtspUrl: url,
        forceRtpTcp: settings.forceRtpTcp
      },
      function (res) {
        if (res && res.httpUrl) {
          onResolved(res.httpUrl);
        } else {
          onError('RTSP service did not return a local stream URL.');
        }
      },
      function (err) {
        onError(err);
      }
    );
  }

  function startPlayback() {
    if (!state.settings.streamUrl) return;
    clearReconnectTimers();

    videoEl.muted = !!state.settings.muteAudio;
    videoEl.volume = state.settings.muteAudio ? 0 : 1;

    setStatus(true, 'Connecting to RTSP stream...', state.settings.streamUrl, true);

    resolvePlayableUrl(
      state.settings,
      function (playableUrl) {
        state.activePlaybackUrl = playableUrl;
        videoEl.src = playableUrl;
        var playPromise = videoEl.play();
        if (playPromise && typeof playPromise.catch === 'function') {
          playPromise.catch(function (err) {
            scheduleReconnect(err && err.message ? err.message : 'Playback blocked');
          });
        }
      },
      function (errText) {
        scheduleReconnect(errText || 'Failed to reach RTSP stream');
      }
    );
  }

  function scheduleReconnect(reason) {
    if (state.currentScreen !== 'viewer') return;
    if (state.reconnectTimer) return;

    state.retryAttempt += 1;
    var idx = Math.min(state.retryAttempt - 1, BACKOFF_DELAYS_SEC.length - 1);
    var remaining = BACKOFF_DELAYS_SEC[idx];

    setStatus(
      true,
      'Stream interrupted · Reconnecting in ' + remaining + 's (Attempt ' + state.retryAttempt + ')',
      reason || '',
      true
    );

    state.countdownTimer = window.setInterval(function () {
      remaining -= 1;
      if (remaining > 0) {
        setStatus(
          true,
          'Stream interrupted · Reconnecting in ' + remaining + 's (Attempt ' + state.retryAttempt + ')',
          reason || '',
          true
        );
      }
    }, 1000);

    state.reconnectTimer = window.setTimeout(function () {
      clearReconnectTimers();
      if (state.currentScreen === 'viewer') {
        startPlayback();
      }
    }, BACKOFF_DELAYS_SEC[idx] * 1000);
  }

  videoEl.addEventListener('playing', function () {
    state.retryAttempt = 0;
    clearReconnectTimers();
    setStatus(false);
  });

  videoEl.addEventListener('waiting', function () {
    if (!state.reconnectTimer && !state.screensaverMode) {
      setStatus(true, 'Buffering stream...', '', true);
    }
  });

  videoEl.addEventListener('error', function () {
    var msg = videoEl.error ? 'Media error code ' + videoEl.error.code : 'Stream connection lost';
    scheduleReconnect(msg);
  });

  videoEl.addEventListener('ended', function () {
    scheduleReconnect('Stream ended by remote host');
  });

  window.addEventListener('online', function () {
    if (state.currentScreen === 'viewer' && state.reconnectTimer) {
      clearReconnectTimers();
      startPlayback();
    }
  });

  // --- Screen Navigation ---
  function showViewer(asScreensaver) {
    state.screensaverMode = !!asScreensaver;
    state.currentScreen = 'viewer';
    settingsScreen.classList.add('hidden');
    viewerScreen.classList.remove('hidden');
    hideFloatingGear();
    startPlayback();
  }

  function showSettings() {
    state.screensaverMode = false;
    state.currentScreen = 'settings';
    stopPlayback();
    hideFloatingGear();
    viewerScreen.classList.add('hidden');
    settingsScreen.classList.remove('hidden');

    var hasUrl = !!state.settings.streamUrl;
    settingsHeading.textContent = hasUrl ? 'Stream & Screensaver Settings' : 'Configure RTSP Stream';
    btnBack.classList.toggle('hidden', !hasUrl);
    btnOpenViewer.classList.toggle('hidden', !hasUrl);
    btnStartScreensaver.classList.toggle('hidden', !hasUrl);

    inputStreamUrl.value = state.settings.streamUrl;
    inputRelayUrl.value = state.settings.relayBaseUrl;
    draftTcp = state.settings.forceRtpTcp;
    draftMute = state.settings.muteAudio;
    updateSwitchUI();
    urlError.classList.add('hidden');

    window.setTimeout(function () {
      inputStreamUrl.focus();
    }, 50);
  }

  function updateSwitchUI() {
    toggleTcp.setAttribute('aria-checked', draftTcp ? 'true' : 'false');
    toggleMute.setAttribute('aria-checked', draftMute ? 'true' : 'false');
  }

  function revealFloatingGear() {
    if (state.screensaverMode || state.currentScreen !== 'viewer') return;
    state.showGearOverlay = true;
    floatingGearBtn.classList.remove('hidden');
    floatingGearBtn.focus();

    if (state.gearTimer) window.clearTimeout(state.gearTimer);
    state.gearTimer = window.setTimeout(hideFloatingGear, 4000);
  }

  function hideFloatingGear() {
    state.showGearOverlay = false;
    floatingGearBtn.classList.add('hidden');
    if (state.gearTimer) {
      window.clearTimeout(state.gearTimer);
      state.gearTimer = null;
    }
  }

  // --- Settings Actions ---
  toggleTcp.addEventListener('click', function () {
    draftTcp = !draftTcp;
    updateSwitchUI();
  });

  toggleMute.addEventListener('click', function () {
    draftMute = !draftMute;
    updateSwitchUI();
  });

  btnSaveTest.addEventListener('click', function () {
    if (state.isTesting) return;
    var candidate = inputStreamUrl.value.trim();
    var validation = validateUrl(candidate);
    if (validation) {
      urlError.textContent = validation;
      urlError.classList.remove('hidden');
      testResultBanner.classList.add('hidden');
      return;
    }

    urlError.classList.add('hidden');
    var updated = {
      streamUrl: candidate,
      relayBaseUrl: inputRelayUrl.value.trim(),
      forceRtpTcp: draftTcp,
      muteAudio: draftMute
    };
    saveSettings(updated);
    btnBack.classList.remove('hidden');
    btnOpenViewer.classList.remove('hidden');
    btnStartScreensaver.classList.remove('hidden');

    state.isTesting = true;
    btnSaveTest.textContent = 'Testing Stream...';
    testResultBanner.classList.add('hidden');

    if (/^rtsp/i.test(candidate) && !updated.relayBaseUrl) {
      callLunaService(
        SERVICE_URI,
        'testStream',
        { rtspUrl: candidate, forceRtpTcp: updated.forceRtpTcp },
        function (res) {
          state.isTesting = false;
          btnSaveTest.textContent = 'Save & Test Stream';
          testResultBanner.className = 'test-banner success';
          testBannerTitle.textContent = 'Settings Saved & Stream Reachable';
          testBannerDetail.textContent =
            (res.codec || 'H.264') + ' · ' + (updated.forceRtpTcp ? 'RTP over TCP' : 'RTP over UDP');
        },
        function (errText) {
          state.isTesting = false;
          btnSaveTest.textContent = 'Save & Test Stream';
          testResultBanner.className = 'test-banner error';
          testBannerTitle.textContent = 'Settings Saved · Stream Test Failed';
          testBannerDetail.textContent = errText;
        }
      );
    } else {
      // HTTP / HLS / Relay test
      var probeUrl = updated.relayBaseUrl
        ? updated.relayBaseUrl.replace(/\/+$/, '') + '/api/stream.mp4?src=' + encodeURIComponent(candidate)
        : candidate;
      var probeVideo = document.createElement('video');
      var settled = false;
      var timeout = window.setTimeout(function () {
        if (settled) return;
        settled = true;
        probeVideo.removeAttribute('src');
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner error';
        testBannerTitle.textContent = 'Settings Saved · Stream Test Timed Out';
        testBannerDetail.textContent = 'No video metadata received within 10s from ' + probeUrl;
      }, 10000);

      probeVideo.muted = true;
      probeVideo.onloadedmetadata = function () {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeout);
        var resLabel =
          probeVideo.videoWidth > 0 ? probeVideo.videoWidth + 'x' + probeVideo.videoHeight : 'Connected';
        probeVideo.removeAttribute('src');
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner success';
        testBannerTitle.textContent = 'Settings Saved & Stream Reachable';
        testBannerDetail.textContent = resLabel + ' · ' + (updated.relayBaseUrl ? 'Relay Gateway' : 'Direct HTTP/HLS');
      };
      probeVideo.onerror = function () {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeout);
        state.isTesting = false;
        btnSaveTest.textContent = 'Save & Test Stream';
        testResultBanner.className = 'test-banner error';
        testBannerTitle.textContent = 'Settings Saved · Stream Test Failed';
        testBannerDetail.textContent = 'Unable to open ' + probeUrl;
      };
      probeVideo.src = probeUrl;
    }
  });

  btnOpenViewer.addEventListener('click', function () {
    showViewer(false);
  });

  btnStartScreensaver.addEventListener('click', function () {
    showViewer(true);
  });

  btnBack.addEventListener('click', function () {
    if (state.settings.streamUrl) {
      showViewer(false);
    }
  });

  floatingGearBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    showSettings();
  });

  // --- Viewer Tap & LG Magic Remote / D-Pad Handling ---
  viewerScreen.addEventListener('click', function () {
    if (state.screensaverMode) {
      exitScreensaver();
      return;
    }
    if (state.showGearOverlay) {
      hideFloatingGear();
    } else {
      revealFloatingGear();
    }
  });

  function exitScreensaver() {
    if (launchedAsScreensaver) {
      stopPlayback();
      window.close();
    } else {
      showSettings();
    }
  }

  document.addEventListener('keydown', function (e) {
    var code = e.keyCode || e.which;

    // In Screensaver mode, ANY button press exits cleanly
    if (state.currentScreen === 'viewer' && state.screensaverMode) {
      e.preventDefault();
      exitScreensaver();
      return;
    }

    // Back key on LG webOS remote (461) or Escape
    if (code === 461 || e.key === 'Escape') {
      if (state.currentScreen === 'settings' && state.settings.streamUrl) {
        e.preventDefault();
        showViewer(false);
      } else if (state.currentScreen === 'viewer' && state.showGearOverlay) {
        e.preventDefault();
        hideFloatingGear();
      } else if (typeof window.webOS !== 'undefined' && window.webOS.platformBack) {
        window.webOS.platformBack();
      }
      return;
    }

    if (state.currentScreen === 'viewer') {
      // OK (13), Menu (457 / 18), Info (457)
      if (code === 13 || code === 457 || code === 18) {
        if (state.showGearOverlay && document.activeElement === floatingGearBtn) {
          showSettings();
        } else {
          revealFloatingGear();
        }
        e.preventDefault();
      }
      return;
    }

    // Simple vertical D-pad focus navigation in Settings
    if (state.currentScreen === 'settings' && (code === 38 || code === 40)) {
      var focusables = Array.prototype.slice.call(
        settingsScreen.querySelectorAll('.tv-focusable:not(.hidden)')
      );
      var idx = focusables.indexOf(document.activeElement);
      if (idx === -1) {
        if (focusables[0]) focusables[0].focus();
        e.preventDefault();
        return;
      }
      var nextIdx = code === 40 ? Math.min(focusables.length - 1, idx + 1) : Math.max(0, idx - 1);
      focusables[nextIdx].focus();
      e.preventDefault();
    }
  });

  // --- Boot ---
  registerScreensaverSuppressor();
  if (!state.settings.streamUrl) {
    showSettings();
  } else {
    showViewer(launchedAsScreensaver);
  }
})();
